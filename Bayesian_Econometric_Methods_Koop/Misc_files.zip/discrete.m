%This function takes draws from a discrete distribution with certain 
%probabilities.  The inputs are values, prob


function out = discrete(values,prob)
loc = 1 + sum(rand(1,1)>cumsum(prob));
out = values(loc);
